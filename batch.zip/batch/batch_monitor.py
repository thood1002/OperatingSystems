import os
import subprocess

# Default jobs directory
jobs_dir = "/mnt/c/users/batch/jobs"  # Update this path for Linux
executables_dir = "/mnt/c/users/batch/executables"  # New directory for executables

def print_divider():
    print("=" * 70) #Printing divider for sections

def list_jobs(): #Listing all available jobs in the directory
    print_divider()
    print("Listing jobs in", jobs_dir)
    try:
        jobs = os.listdir(jobs_dir)
        for index, job in enumerate(jobs, start=1):
            print(f"{index}. {job}")
    except FileNotFoundError:
        print("Jobs directory not found.")

def set_jobs_directory(): #Changing jobs directory path
    print_divider()
    global jobs_dir
    new_dir = input("Enter the new jobs directory (WSL path): ")

    if os.path.exists(new_dir):
        jobs_dir = new_dir
        print("Jobs directory set to", jobs_dir)
    else:
        print("Directory not found. Jobs directory remains", jobs_dir)

def compile_and_run_program(program_name):
    """Compile and run a specific C program."""
    print_divider()
    program_path = os.path.join(jobs_dir, program_name)
    if os.path.isfile(program_path) and program_name.endswith(".c"):
        executable_name = program_name.rstrip(".c")
        executable_path = os.path.join(executables_dir, executable_name)

        print(f"Compiling and running {program_name}...")
        compile_command = f"gcc -o '{executable_path}' '{program_path}'"
        run_command = f"./{executable_name}"
        
        # Compile the program
        subprocess.run(compile_command, shell=True, cwd=executables_dir)

        # Run the program
        subprocess.run(run_command, shell=True, cwd=executables_dir)




def compile_and_run_all_jobs(): #Compiling and running all jobs in directory
    print_divider()
    try:
        jobs = os.listdir(jobs_dir)
        for job in jobs:
            compile_and_run_program(job)
    except FileNotFoundError:
        print("Jobs directory not found.")

def main():
    # Ensure the executables directory exists
    os.makedirs(executables_dir, exist_ok=True)

    while True:
        print_divider()
        print("\nBatch Monitor Menu:")
        print("1. List Jobs")
        print("2. Set Jobs Directory")
        print("3. Compile and Run Specific Program")
        print("4. Compile and Run All Jobs")
        print("5. Shutdown")
        print("6. List Program Options")
        print("7. Help")

        choice = input("Enter your choice: ")
        if choice == '1':
            list_jobs()
            print_divider()
        elif choice == '2':
            set_jobs_directory()
            print_divider()
        elif choice == '3':
            program_name = input("Enter program name: ")
            compile_and_run_program(program_name)
            print_divider()
        elif choice == '4':
            compile_and_run_all_jobs()
            print_divider()
        elif choice == '5':
            break
        elif choice == '6':
            print_divider()
            print("Program Options: *insert options i couldnt think of any*")
        elif choice == '7':
            print_divider()
            print("\nBatch Monitor Help:")
            print("1. List Jobs: List all available jobs in the jobs directory.")
            print("2. Set Jobs Directory: Change the jobs directory path.")
            print("3. Compile and Run Specific Program: Enter a program name to compile and run it.")
            print("4. Compile and Run All Jobs: Compile and run all programs in the jobs directory.")
            print("5. Shutdown: Exit the Batch Monitor program.")
            print("6. List Program Options: List program options.")
            print("7. Help: Display this help message.")
        else:
            print_divider()
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

